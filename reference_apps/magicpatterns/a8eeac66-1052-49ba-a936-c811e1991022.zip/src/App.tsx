import React from 'react';
import { Presentation } from './components/presentation/Presentation';
export function App() {
  return <div className="w-full min-h-screen bg-gray-100">
      <Presentation />
    </div>;
}